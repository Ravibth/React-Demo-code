import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {
  const [todo, setTodo] = useState('');
  const [name, setName] = useState('');
  const [age, setAge] = useState(0);
  const [universites, setUniversites] = useState([]);

  const myClickHandler = () => {
    const url = 'https://www.boredapi.com/api/activity';
    const getData = async () => {
      const result = await fetch(url);
      result.json().then(data => {
        console.log(data);
        setTodo(data.activity);
      });
    }

    getData();
  }

  const guessAgeHandler = () => {
    const url = 'https://api.agify.io?name=' + name;
    console.log(url);
    const getData = async () => {
      const result = await fetch(url);
      result.json().then(data => {
        console.log(data);
        setAge(data.age);
      });
    }

    getData();
  }

  const universityDataHandler = () => {
    const url = 'http://universities.hipolabs.com/search?country=Canada';
    const getData = async () => {
      const result = await fetch(url);
      result.json().then(data => {
        console.log(data);
        setUniversites(data);
      });
    }

    getData();
  } 

  return (
    <div className="App">
      <h2>Welcome to the App</h2>
      <hr />
      <button onClick={myClickHandler}>Bored? Find something to do</button>
      <p>{todo}</p>
      <hr />
      Enter name: <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      <br/>
      <button onClick={guessAgeHandler}>Guess Age</button>
      <p>Your age is: {age}</p>
      <hr />
      <button onClick={universityDataHandler}>Get Universities of India</button>
      <table>
        <thead>
          <th>University</th>
          <th>Website</th>
          <th>country</th>
        </thead>
        <tbody>
          {universites.map((university) => {
            return(
              <tr>
                <td>{university.name}</td>
                <td><a href={university.web_pages[0]} target='_blank'>{university.web_pages[0]}</a></td>
                <td>{university.country}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default App;
