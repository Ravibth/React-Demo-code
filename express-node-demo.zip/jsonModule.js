const express = require('express');
const fs = require('fs');

const app = new express();
app.use(express.json());

const jsonFile = "jsonDataFile.json";

//Get all data
app.get('/person/all', (req, res) => {
    const myContent = fs.readFileSync(jsonFile);

    res.setHeader('content-type', 'application/json');
    res.send(myContent);
});

//Get data by id
app.get('/person/:id', (req, res) => {
    const myContent = fs.readFileSync(jsonFile);
    let jsonData = JSON.parse(myContent);
    
    let person = jsonData.find(p => p.id == req.params.id);

    res.setHeader('content-type', 'application/json');
    res.send(person);
});

//Add person
app.post('/person', (req, res) => {
    let body = req.body;

    const myContent = fs.readFileSync(jsonFile);
    let jsonData = JSON.parse(myContent);

    jsonData.push({id: body.id, name: body.name, email: body.email});
    console.log(jsonData);
    fs.writeFileSync(jsonFile, JSON.stringify(jsonData));

    res.send(body);
});

//Updating the person
app.put('/person/:id', (req, res) => {
    const myContent = fs.readFileSync(jsonFile);
    let jsonData = JSON.parse(myContent);
    
    let person = jsonData.find(p => p.id == req.params.id);

    person.name = req.body.name;
    person.email = req.body.email;

    fs.writeFileSync(jsonFile, JSON.stringify(jsonData));

    res.setHeader('content-type', 'application/json');
    res.send(person);
});

//Updating the person
app.delete('/person/:id', (req, res) => {
    const myContent = fs.readFileSync(jsonFile);
    let jsonData = JSON.parse(myContent);
    
    let person = jsonData.find(p => p.id == req.params.id);
    let index = jsonData.indexOf(person);
    console.log(index);

    jsonData.splice(index, 1);

    fs.writeFileSync(jsonFile, JSON.stringify(jsonData));

    res.setHeader('content-type', 'application/json');
    res.send(person);
});

const port = 3300;
app.listen(port, () => {
    console.log(`Server is up and running on port ${port}`);
});