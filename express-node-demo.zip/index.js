const cors = require('cors');
const express = require('express');

const app = new express();
app.use(cors());

const activities = [
    "Create a react app",
    "Play any outdoor game",
    "Listen some calm music",
    "Play any indoor game",
    "Watch a movie",
    "Watch IPL",
    "Scroll instagram",
    "Take a nap",
    "Go on long drive",
    "Spend time with friends"
];

//Using path variable
app.get('/activity/:id', (req, res) => {
    console.log("activity API called with path variable");
    let result = {
        activity: activities[req.params.id]
    };
    res.setHeader('content-type', 'application/json');
    res.send(JSON.stringify(result));
});

app.get('/activity', (req, res) => {
    console.log("activity API called");
    let id = Math.floor(Math.random() * 10);
    console.log(id);
    let result = {
        activity: activities[id]
    };
    res.setHeader('content-type', 'application/json');
    res.send(JSON.stringify(result));
});

const port = 3300;
app.listen(port, () => {
    console.log(`Server is up and running on port ${port}`);
});