import { useState } from "react";

const AddUser = ({dataChanged}) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [age, setAge] = useState('');

    const clickHandler = () => {
        const url = 'http://localhost:3002/api/user';
        const saveData = async (payload) => {
            try {
                const result = await fetch(url, {
                    method: 'POST',
                    body: JSON.stringify(payload),
                    headers: {
                        "Content-Type" : "Application/json"
                    }
                });
                result.json()
                .then(jsonData => {
                    console.log(jsonData)
                    dataChanged();
                })
                .catch(error => console.log(error))
            } catch (error) {
                console.log(error);
            }
        }
        const payload = {
            Name: name,
            EmailId: email,
            Age: age
        }
        saveData(payload);
    }

    return(
        <>
            <table>
                <tr>
                    <td>Enter Name</td>
                    <td><input type="text" value={name} onChange={(e) => setName(e.target.value)} /></td>
                </tr>
                <tr>
                    <td>Enter Email</td>
                    <td><input type="text" value={email} onChange={(e) => setEmail(e.target.value)} /></td>
                </tr>
                <tr>
                    <td>Enter Age</td>
                    <td><input type="text" value={age} onChange={(e) => setAge(e.target.value)} /></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button onClick={clickHandler}>Save</button></td>
                </tr>
            </table>
            <hr/>
        </>
    );
}

export default AddUser;