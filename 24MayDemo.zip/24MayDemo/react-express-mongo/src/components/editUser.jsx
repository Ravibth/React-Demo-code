import { useEffect, useState } from "react";

const EditUser = ({userId, dataChanged}) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [age, setAge] = useState('');


    useEffect(() => {
        console.log(userId);
        const url = `http://localhost:3002/api/user/${userId}`;
        const getData = async () => {
            try {
                const result = await fetch(url);
                result.json()
                .then(jsonData => {
                    console.log(jsonData);
                    setName(jsonData.Name);
                    setEmail(jsonData.EmailId)
                    setAge(jsonData.Age);
                })
                .catch(error => console.log(error))
            } catch (error) {
                console.log(error);
            }
        }
        getData();
    }, [userId]);
    const clickHandler= () => {
        const url = `http://localhost:3002/api/user/${userId}`;
        const saveData = async (payload) => {
            try {
                const result = await fetch(url, {
                    method: 'PUT',
                    body: JSON.stringify(payload),
                    headers: {
                        "Content-Type" : "Application/json"
                    }
                });
                result.json()
                .then(jsonData => {
                    console.log(jsonData)
                    dataChanged();
                })
                .catch(error => console.log(error))
            } catch (error) {
                console.log(error);
            }
        }
        const payload = {
            Name: name,
            EmailId: email,
            Age: age
        }
        saveData(payload);
    }
    return(
        <>
            <table>
                <tr>
                    <td>Enter Name</td>
                    <td><input type="text" value={name} onChange={(e) => setName(e.target.value)} /></td>
                </tr>
                <tr>
                    <td>Enter Email</td>
                    <td><input type="text" value={email} onChange={(e) => setEmail(e.target.value)} /></td>
                </tr>
                <tr>
                    <td>Enter Age</td>
                    <td><input type="text" value={age} onChange={(e) => setAge(e.target.value)} /></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button onClick={clickHandler}>Update</button></td>
                </tr>
            </table>
            <hr/>
        </>
    );
}

export default EditUser;