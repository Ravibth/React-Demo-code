import { useEffect, useState } from "react";

const GetAllUsers = ({changedTime, dataChanged, ToEdit}) => {
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const url = 'http://localhost:3002/api/user/all';
        const getData = async () => {
            try {
                const result = await fetch(url);
                result.json()
                .then(jsonData => {
                    console.log(jsonData);
                    setUsers(jsonData);
                })
                .catch(error => console.log(error))
            } catch (error) {
                console.log(error);
            }
        }
        getData();
    }, [changedTime]);

    const deleteHandler = (userId) => {
        const url = `http://localhost:3002/api/user/${userId}`;
        const deleteData = async ()=>{
            try {
                const result = await fetch(url, {
                    method: 'DELETE'
                });
                result.json()
                .then(jsonData => {
                    console.log(jsonData)
                    dataChanged();
                })
                .catch(error => console.log(error))
            } catch (error) {
                console.log(error);
            }
        }
        deleteData();
    }
    return(
        <>
           <table>
           <thead>
            <th>Id</th>
            <th>Name</th>
            <th>EmailId</th>
            <th>Age</th>
            <th>Actions</th>
            </thead> 
            <tbody>
                {
                    users.map((user) => {
                        return(
                        <tr>
                            <td>{user._id}</td>
                            <td>{user.Name}</td>
                            <td>{user.EmailId}</td>
                            <td>{user.Age}</td>
                            <td>
                                <button onClick={()=> deleteHandler(user._id)}>Delete</button>
                                <button onClick={() => ToEdit(user._id)}>Edit</button>
                            </td>
                        </tr>
                        );
                    })
                }
            </tbody>
           </table>
           <hr/>
        </>
    );
}

export default GetAllUsers;