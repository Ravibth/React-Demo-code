import logo from './logo.svg';
import './App.css';
import GetAllUsers from './components/getAllUsers';
import AddUser from './components/addUser';
import { useCallback, useState } from 'react';
import EditUser from './components/editUser';

const getCurrentTime = () => new Date().toLocaleTimeString();

function App() {
  const [updatedTime, setUpdatedTime] = useState(getCurrentTime());
  const [userToEdit, setUserToEdit] = useState('');
  
  const childDataChanged = useCallback(() => {
    setUpdatedTime(getCurrentTime());
  }, [updatedTime]);

  const toEdit = (userId) => {
    setUserToEdit(userId);
  }

  return (
    <div className="App">
      <AddUser dataChanged={childDataChanged}></AddUser>
      <EditUser userId = {userToEdit} dataChanged={childDataChanged}></EditUser>
      <GetAllUsers changedTime={updatedTime} dataChanged={childDataChanged} ToEdit = {toEdit}></GetAllUsers>
    </div>
  );
}

export default App;
