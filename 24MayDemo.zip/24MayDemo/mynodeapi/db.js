const { MongoClient } = require('mongodb');

const url = 'mongodb://localhost:27017';
const dbName = 'mydemoDB';
const client = new MongoClient(url, { useNewUrlParser: true, 
  useUnifiedTopology: true });

let db;

async function connectToDatabase() {
  if (!db) {
    console.log("testing");
    await client.connect();
    console.log('Connected successfully to MongoDB server');
    console.log("DBName",dbName);
    db = client.db(dbName);
  }
  return db;
}

module.exports = connectToDatabase;
