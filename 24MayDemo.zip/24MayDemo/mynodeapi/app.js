const express = require('express');
const cors = require('cors');
const itemRoutes = require('./routes/items');

const app = express();

// Middleware to parse JSON bodies
app.use(express.json());
app.use(cors());

// Use the item routes
app.use('/api/', itemRoutes);

const port = 3002;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
