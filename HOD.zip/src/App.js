import logo from './logo.svg';
import './App.css';
import MyComponentWithLoading from './higher-component/myComponentWithLoading'
function App() {
  return (
    <div className="App">
      <MyComponentWithLoading data="Higher component data load"></MyComponentWithLoading>
      <MyComponentWithLoading data="Higher component data load-01"></MyComponentWithLoading>
    </div>
  );
}

export default App;
