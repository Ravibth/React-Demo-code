// MyComponent.js
import React from 'react';
import withLogger from './withLogger';

class MyComponent extends React.Component {
  render() {
    return <div>My Component</div>;
  }
}

export default withLogger(MyComponent);
