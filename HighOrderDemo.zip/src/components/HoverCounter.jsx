import { useState } from "react";
import withCounter from "./withCounter";

function HoverCounter({name, count, setCount}) {
    //const [count, setCount] = useState(0);
    return(
        <>
            <button onMouseOver={() => setCount(count+1)}>Click me..!!</button>
            <p>{name}: {count}</p>
            <hr/>
        </>
    );
}
export default withCounter(HoverCounter);