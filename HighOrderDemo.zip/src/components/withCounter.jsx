import { useState } from "react";

function withCounter(OldComp) {
    return function NewComp(props) {
        const [count1, setCount1] = useState(0);
        return(
            <>
                <h2>I'm High order component</h2>
                <OldComp {...props} count={count1} setCount={setCount1}></OldComp>
            </>
        );
    }
}

export default withCounter;