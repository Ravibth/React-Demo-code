import React, { useState, useEffect } from 'react';

// Define the higher-order component
 const withLoading = (WrappedComponent) => {
  return function WithLoadingComponent(props) {
    const [loading, setLoading] = useState(true);
   
    // Render the wrapped component with props
    return <WrappedComponent {...props} />;
  };
};

// Define a component to be wrapped by the higher-order component
 const MyComponentHOD = ({ data }) => {
  return (
    <div>
      <h1>Data Loaded Successfully!</h1>
      <p>{data}</p>
    </div>
  );
};

const MyComponentHOD01 = ({ data }) => {
  return (
    <div>
      
      <h1>Data Loaded Successfully!</h1>
      <p>
      MyComponentHOD01
      </p>
      <p>{data}</p>
    </div>
  );
};
export default MyComponentHOD;
 

// export default MyComponentHOD;
// Wrap MyComponent with withLoading HOC
const MyComponentWithLoading = withLoading(MyComponentHOD);
 const MyComponentWithLoading01 = withLoading(MyComponentHOD01);
