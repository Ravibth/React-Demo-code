import logo from './logo.svg';
import './App.css';
import MyComponentWithLoading from './higher-component/myComponentWithLoading'
import ClickCounter from './components/ClickCounter';
import HoverCounter from './components/HoverCounter';
function App() {
  return (
    <div className="App">
      {/* <MyComponentWithLoading data="Higher component data load"></MyComponentWithLoading>
      <MyComponentWithLoading data="Higher component data load-01"></MyComponentWithLoading> */}
      <h1>I'm app</h1>
      <ClickCounter name="ClickCounter"></ClickCounter>
      <HoverCounter name="HoverCounter"></HoverCounter>
    </div>
  );
}

export default App;
