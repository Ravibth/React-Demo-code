const cors = require('cors');
const express = require('express');

//Importing routes
const activityRoutes = require('./routes/activityRoutes');
const simpleRoutes = require('./routes/simpleRoutes');
const personRoutes = require('./routes/personRoutes')

//Creating app and using middlewares
const app = new express();
app.use(cors());
app.use(express.json());

//Using routes
const routePrefix = '/api/v1/';
app.use(routePrefix, activityRoutes);
app.use(routePrefix, simpleRoutes);
app.use(routePrefix, personRoutes);

//Export App
module.exports = app;