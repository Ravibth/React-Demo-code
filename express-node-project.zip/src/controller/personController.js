const personService = require('../services/personService');
const Person = require('../models/person');

const getAllPersons = (req, res) => {
    let result = personService.getAllPersons();
    
    res.setHeader('content-type', 'application/json');
    res.send(result);
}

const addPerson = (req, res) => {
    let body = req.body;
    let person = new Person(body.id, body.name, body.email);
    
    let result = personService.addPerson(person);

    res.send(result);
}

const getPersonById = (req, res) => {
    let id = req.params.id;
    let result = personService.getPersonById(id);

    res.setHeader('content-type', 'application/json');
    res.send(result);
}

module.exports = {
    getAllPersons,
    addPerson,
    getPersonById
}