const activityService = require('../services/activityService');

const getActivity = (req, res) => {
    let result = activityService.getActivity();
    res.setHeader('content-type', 'application/json');
    res.send(JSON.stringify(result));
}

const getActivityById = (req, res) => {
    let result = activityService.getActivityById(req.params.id);
    res.setHeader('content-type', 'application/json');
    res.send(JSON.stringify(result));
};

module.exports = {
    getActivity,
    getActivityById
}