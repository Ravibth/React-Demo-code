const simpleService = require('../services/simpleService');

const getSimple = (req, res) => {
    let result = simpleService.getSimple();
    res.send(result);
}

module.exports = {
    getSimple
}