
const activities = [
    "Create a react app",
    "Play any outdoor game",
    "Listen some calm music",
    "Play any indoor game",
    "Watch a movie",
    "Watch IPL",
    "Scroll instagram",
    "Take a nap",
    "Go on long drive",
    "Spend time with friends"
];

const getActivity = () => {
    let id = Math.floor(Math.random() * 10);
    let result = {
        activity: activities[id]
    };
    return result;
}

const getActivityById = (id) => {
    let result = {
        activity: activities[id]
    };
    return result;
}

module.exports = {
    getActivity,
    getActivityById
}