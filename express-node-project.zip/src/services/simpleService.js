const getSimple = () => {
    return "Simple";
}

module.exports = {
    getSimple
}