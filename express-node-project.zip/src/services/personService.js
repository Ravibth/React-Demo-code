const fs = require('fs');

const jsonFile = 'jsonData.json';

const getAllPersons = () => {
    const myContent = fs.readFileSync(jsonFile);
    return myContent;
}

const addPerson = (person) => {
    const myContent = fs.readFileSync(jsonFile);
    let jsonData = JSON.parse(myContent);

    jsonData.push(person);
    fs.writeFileSync(jsonFile, JSON.stringify(jsonData));

    return person;
}

const getPersonById = (id) => {
    const myContent = fs.readFileSync(jsonFile);
    let jsonData = JSON.parse(myContent);
    let person = jsonData.find(p => p.id == id);

    return person;
}

module.exports = {
    getAllPersons,
    addPerson,
    getPersonById
}