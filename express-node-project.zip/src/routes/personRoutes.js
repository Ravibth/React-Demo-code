const express = require('express');
const route = express.Router();

const personController = require('../controller/personController');

route.get('/person/all', personController.getAllPersons);
route.post('/person', personController.addPerson);
route.get('/person/:id', personController.getPersonById);

module.exports = route;