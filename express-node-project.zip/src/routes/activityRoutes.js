const express = require('express');
const route = express.Router();

//Importing controller
const activityController = require('../controller/activityController');

//Mapping endpoint with controller method
route.get('/activity', activityController.getActivity);
route.get('/activity/:id', activityController.getActivityById);

module.exports = route;