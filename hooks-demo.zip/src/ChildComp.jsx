import { memo, useEffect, useState } from "react";

function ChildComp() {
    const [count, setCount] = useState(0);
    useEffect(() => {
        console.log("Child is rendered.");
    });
    return(
        <>
            <hr />
            <p>Hello, I'm Child Comp.</p>
            <button onClick={() => setCount(count + 1)}>Click me..!!</button>
            <p>Count: {count}</p>
        </>
    );
}

export default memo(ChildComp);