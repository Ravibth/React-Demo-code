import './App.css';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import ChildComp from './ChildComp';
import ChildProp from './ChildProp';

function App() {
  const [count, setCount] = useState(0);
  const [count1, setCount1] = useState(0);

const myFunc = () => {
  return new Date().toTimeString();
}

  const myFuncNew = useCallback(() => {   return new Date().toTimeString(); }, [count1]);
  const oldTime = useMemo(myFunc, []);
  const newTime = useMemo(myFunc, [count1]);

  let i = useRef(0);

  useEffect(() => {
    i.current = i.current + 1;
    console.log(i.current);
    console.log("App is rendered.");
  });

  useEffect(() => {
    console.log("Count is rendered.");
  }, [count]);

  

  return (
    <div className="App">
      <button onClick={() => setCount(count + 1)}>Click me..!!</button>
      <button onClick={() => setCount1(count1 + 1)}>Click me1..!!</button>
      <p>Count: {count}</p>
      <p>Count1: {count1}</p>
      <p>oldTime: {oldTime}</p>
      <p>newTime: {newTime}</p>
      <ChildComp></ChildComp>
      <ChildProp someCallback={myFuncNew}></ChildProp>
    </div>
  );
}

export default App;
