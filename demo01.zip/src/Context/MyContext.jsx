import React, {createContext} from "react";

const MyContext = createContext("Default Data")

export default MyContext;