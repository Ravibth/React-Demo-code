// import logo from './logo.svg';
// import './App.css';
// import Welcome from './welcome/welcome';
// import Home from './welcome/home/home';
// import { Component, useContext } from 'react';
// import About from './welcome/function_component/about';
// import FormComp from './welcome/function_component/FormComp';
// import RouteConfig from './router/router';
// import ChildOne from './components/ChildOne'
// import MyContext from './Context/MyContext';

// class App extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       firstName : "Amit"
//     }    
//   }

//  formSubmit = (data) => {
//    console.log("Name:",data)
//    this.setState({firstName: "Rohit"});
//   }
//   render() {
//     let x = useContext(MyContext);
//     return (
//       <div className="App">
//          {/* <Welcome name="Ravi Kumar 1" age="25"></Welcome>
//          <div></div>
//        <Home firstName={this.state.firstName}></Home>
//        <About></About> */}
//        {/* <FormComp onFormSubmit= {(e)=>this.formSubmit(e)} firstname={this.state.firstName}></FormComp> */}
//       {/* <RouteConfig></RouteConfig> */}
      
      
//     <div>
//       <MyContext.Provider value="Updated by App">
//         <p>{x}</p>
//       <ChildOne></ChildOne>
//       </MyContext.Provider>
//   </div>
//       </div>
//     );
//   }  
// }

// export default App;


import { useContext } from 'react';
import './App.css';
import ChildOne from './components/ChildOne';
import MyContext from './Context/MyContext';

function App() {
  let x = useContext(MyContext);
  return (
    <div>
      <MyContext.Provider value="Updated by App">
        <p>{x}</p>
      <ChildOne></ChildOne>
      </MyContext.Provider>
    </div>
  );
}

export default App;
