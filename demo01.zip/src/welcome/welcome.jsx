export default function Welcome_01 (props) {
    return (
        <>
        Welcome in React {props.name}
        </>
    )
}


// export default Welcome_01;

export  function Welcome ({name, age}) {
    return (
        <>
        Welcome to {name}. Age is {age}
        </>
    )
}
