import { useEffect, useState } from "react"

export default function About()  {
    const [count,setCount] = useState(0);
    const [msg,setMsg] = useState("");
    const clickMe =()=> {
       // alert("You Clicked Me.")
        let _count = count +1;        
        setCount(_count)
    }
    useEffect(()=>{
        try {
        const _date = new Date ("test");   
        console.log(_date);
        try {
        let age = 20;
        age = 20 + parseInt("test");
        console.log(age);
        } catch(ex) {

        }
        setCount(1);

        }
        catch(ex) {
            console.log("Error",ex);
        }
    },[])

    useEffect(()=>{
        if(count > 1)
        setMsg("You had clicked Me.")
    },[count])
    return (
        <>
        <hr />
        Welcome in About us Page.
        <div>
            Count: {count} 
           
        </div>
        <div>
        Message: {msg}
        </div>
        <div>
        <button onClick={clickMe}>Click me</button>
        </div>
        </>
    )
}