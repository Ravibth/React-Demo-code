import { useEffect, useState } from "react";

export default function FormComp (props) {
    const [name, setName] = useState('');
    const [age, setAge] = useState(0);
    const [email, setEmail] = useState('');

    const formHandler = (e) => {
        e.preventDefault();
        //props.onFormSubmit("Ravi");
        console.log(name);
        console.log(age);
        console.log(email);
    } 
    useEffect(()=>{
      setName(props.firstname);
    },[props.firstname])

    // useEffect(()=>{},[])
    return(
        <>
        <hr/>
        Name: {name}
        <div>
            <form onSubmit={formHandler}>
                Name: <input type="text" value={name} onChange={(e) => setName(e.target.value)}/>
                <br/>
                Age: <input type="number" value={age} onChange={(e) => setAge(e.target.value)} />
                <br />
                Email: <input type="text" value={email} onChange={(e) => setEmail(e.target.value)}/>
                <br/>
                <button type="submit">Submit</button>
            </form>
        </div>
        </>
    );
}