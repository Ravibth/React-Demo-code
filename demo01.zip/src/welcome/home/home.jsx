import { click } from "@testing-library/user-event/dist/click";
import { Component } from "react"
let location = "Delhi";
export default class Home extends Component {
    constructor(props) {
        super(props);
        console.log("welcome in constructor");
        this.state = {
            name : "ravindra",
            age: "35",
            clickCount: 0
        }
    }

    componentDidMount() {
        // this.setState({
        //     name: "Ravindra Kumar",
        //     age: 40
        // });
        // this.setState({
        //     age: 25
        // })
        console.log("Component did mount");
        location = "Nodia";
    }
componentDidUpdate(prevProps, prevState ) {
    if (prevProps.firstName != this.props.firstName) {
        
    }
    console.log("Component did update");
}


 handleClick = () => {
    let Count = this.state.clickCount + 1;
    this.setState({
        clickCount: Count
    })
}
htmlRender=() => {
    return (
        <>
        Welcome in Class Components {this.state.name}
        <div>
        FirstName = {this.props.firstName}
        </div>
        <div>
        Age:{this.state.age}
        </div>
        <div>
        Location: {location}
        </div>
        <div>
           <button onClick={this.handleClick}>Click Me</button>
        </div>
        Click Count: {this.state.clickCount}
        </>
    )
}
  render() {
    console.log("render");
    return <>    
     Welcome in Class Components {this.state.name}
        <div>
        FirstName = {this.props.firstName}
        </div>
        <div>
        Age:{this.state.age}
        </div>
        <div>
        Location: {location}
        </div>
        <div>
           <button onClick={this.handleClick}>Click Me</button>
        </div>
        Click Count: {this.state.clickCount}
    </>
  }
}