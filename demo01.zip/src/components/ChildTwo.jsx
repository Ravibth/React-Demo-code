import { useContext } from "react";
import ChildThree from "./ChildThree";
import MyContext from "../Context/MyContext";

export default function ChildTwo() {
    let x = useContext(MyContext);
    return(
        <>
            <MyContext.Provider value="Updated By Child two">
            <h2>Child Two. {x}</h2>
            <hr />
            <ChildThree></ChildThree>
            </MyContext.Provider>
        </>
    );
}