import { useContext } from "react";
import MyContext from "../Context/MyContext";

export default function ChildFour() {
    let x = useContext(MyContext);
    return(
        <>
            <h4>Child Four. {x}</h4>
            <hr />
        </>
    );
}