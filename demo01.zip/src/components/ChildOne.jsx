import { useContext } from "react";
import ChildTwo from "./ChildTwo";
import MyContext from "../Context/MyContext";

export default function ChildOne() {
    let x = useContext(MyContext);
    return(
        <>
            <h1>Child One. {x}</h1>
            <hr />
            <ChildTwo></ChildTwo>
        </>
    );
}