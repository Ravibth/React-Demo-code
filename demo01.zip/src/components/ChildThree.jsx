import { useContext } from "react";
import ChildFour from "./ChildFour";
import MyContext from "../Context/MyContext";

export default function ChildThree() {
    let x = useContext(MyContext);
    return(
        <>
        <MyContext.Provider value="Updated By Child Three">
            <h3>Child Three. {x}</h3>
            <hr />
            <ChildFour></ChildFour>
            </MyContext.Provider>
        </>
    );
}