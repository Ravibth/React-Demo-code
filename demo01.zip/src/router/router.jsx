import React from 'react';
//import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import { Routes, Route, BrowserRouter as Router } from "react-router-dom";

import Home from './home';
import About from './about';
import Contact from './contact';

export default function RouteConfig  ()  {
    return (
        <>
          <Router>
        <Routes> 
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/About" element={<About />} />
          <Route path="/Contact" element={<Contact />} />

        </Routes>
        </Router>
        </>
    )
}