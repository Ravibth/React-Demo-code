import logo from './logo.svg';
import './App.css';
import Welcome from './welcome/welcome';
import Home from './welcome/home/home';
import { Component } from 'react';
import About from './welcome/function_component/about';
import FormComp from './welcome/function_component/FormComp';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName : "Amit"
    }    
  }

 formSubmit = (data) => {
   console.log("Name:",data)
   this.setState({firstName: "Rohit"});
  }
  render() {
    return (
      <div className="App">
         {/* <Welcome name="Ravi Kumar 1" age="25"></Welcome>
         <div></div>
       <Home firstName={this.state.firstName}></Home>
       <About></About> */}
       <FormComp onFormSubmit= {(e)=>this.formSubmit(e)} firstname={this.state.firstName}></FormComp>
      </div>
    );
  }  
}

export default App;
