const express = require('express');
const itemRoutes = require('./routes/items');
const app = express();
const port = 3002;
// Middleware to parse JSON bodies
app.use(express.json());
// Use the item routes
app.use('/api/', itemRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
