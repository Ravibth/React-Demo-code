const express = require('express');
const { ObjectId } = require('mongodb');
const connectToDatabase = require('../db');

const router = express.Router();
 
// Create
router.post('/user', async (req, res) => {
  try {
    const db = await connectToDatabase();
    const collection = db.collection('users');
    console.log("Body:", req.body);
    const result = await collection.insertOne(req.body);
    res.status(201).send(result);
  } catch (error) {
    console.log("Error:", error)
    res.status(500).send({ error: `Failed to create item ${error}` });
  }
});

// Read all
router.get('/user/all', async (req, res) => {
  try {
    const db = await connectToDatabase();
    const collection = db.collection('users');
    const items = await collection.find({}).toArray();
    res.send(items);
  } catch (error) {
    res.status(500).send({ error: `Failed to fetch items ${error}` });
  }
});

// Read one
router.get('/user/:id', async (req, res) => {
  try {
    const db = await connectToDatabase();
    const collection = db.collection('users');
    
    const item = await collection.findOne({ _id: new ObjectId(req.params.id) });
    if (item) {
      res.send(item);
    } else {
      res.status(404).send({ error: 'Item not found' });
    }
  } catch (error) {
    res.status(500).send({ error: 'Failed to fetch item' });
  }
});

// Update
router.put('/user/:id', async (req, res) => {
  try {
    const db = await connectToDatabase();
    const collection = db.collection('users');
    console.log("ID:",req.params.id);
    const result = await collection.updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: req.body }
    );
    if (result.modifiedCount > 0) {
      res.send({ message: 'Item updated' });
    } else {
      res.status(404).send({ error: 'Item not found' });
    }
  } catch (error) {
    res.status(500).send({ error: 'Failed to update item' });
  }
});

// Delete
router.delete('/user/:id', async (req, res) => {
  try {
    const db = await connectToDatabase();
    const collection = db.collection('users');
    const result = await collection.deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount > 0) {
      res.send({ message: 'Item deleted' });
    } else {
      res.status(404).send({ error: 'Item not found' });
    }
  } catch (error) {
    res.status(500).send({ error: 'Failed to delete item' });
  }
});

module.exports = router;
